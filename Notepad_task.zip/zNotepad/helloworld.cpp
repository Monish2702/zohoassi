#include <iostream>
#include "employee.pb.h"

int main() 
{
    std::cout<<"hello";
    monish::Employee emp;
}